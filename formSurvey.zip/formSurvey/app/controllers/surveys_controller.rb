class SurveysController < ApplicationController
    def main
        if !session[:views]
            session[:views] = 0
        end

    end
    def results
        @results = params

    end
    def flash_session
        session[:views] = session[:views] + 1
        session[:answer] = params[:survey]
        falsh[:success] = "You have submitted this form #{session[:views]} times."
    end
    

end
